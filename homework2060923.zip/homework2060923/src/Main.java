import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double price = scanner.nextDouble();
        double money = scanner.nextDouble();
        double change = money - price;
        double dollar = (int) change;
        double cent = (change * 100) % 100;
        System.out.print(price);
        System.out.print(money);
        System.out.print(change);
        System.out.print(dollar);
        System.out.print(cent);

    }
}